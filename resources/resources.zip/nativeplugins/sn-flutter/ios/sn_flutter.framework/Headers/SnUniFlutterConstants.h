//
//  SnUniFlutterConstants.h
//  Pods
//
//  Created by itfenbao on 2021/3/15.
//

#define CHANNEL @"com.itfenbao.uniapp"
#define FLUTTER_MESSAGE @"flutter_message"

#define CAN_POP @"canPop"
#define POP @"pop"
#define GET_PARAMS @"getParams"
#define CALL_BACK_METHOD @"_uni_callback"


#define POP_CHANGE @"popChange"
