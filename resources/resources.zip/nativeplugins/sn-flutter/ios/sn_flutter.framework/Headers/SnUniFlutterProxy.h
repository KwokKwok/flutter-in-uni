//
//  SnUniFlutterProxy.h
//  sn-flutter
//
//  Created by itfenbao on 2021/2/25.
//

#import <Foundation/Foundation.h>
#import "Flutter/Flutter.h"
#import "DCUni/UniPluginProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface SnUniFlutterProxy : NSObject<UniPluginProtocol>

@end

NS_ASSUME_NONNULL_END
