//
//  SnUniFlutterModule.h
//  sn-flutter
//
//  Created by itfenbao on 2021/2/25.
//

#import <Foundation/Foundation.h>
#import "Flutter/Flutter.h"
#import "DCUni/DCUniModule.h"

NS_ASSUME_NONNULL_BEGIN

@interface SnUniFlutterModule : DCUniModule

@end

NS_ASSUME_NONNULL_END
