//
//  SnUniFlutterComponent.h
//  sn-flutter
//
//  Created by itfenbao on 2021/2/25.
//

#import <Foundation/Foundation.h>
#import "Flutter/Flutter.h"
#import "DCUni/DCUniComponent.h"
#import "SnUniFlutterMsgProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface SnUniFlutterComponent : DCUniComponent<SnUniFlutterMsgProtocol>

@end

NS_ASSUME_NONNULL_END
